<table border=1>
        <tr> <th>Origen </th>
             <th>Destino</th>
             <th>Fecha  </th>
             <th>Horario</th>
        </tr>
<?php

include("con.inc");

$iDate = $_GET["iDate"];
$fDate = $_GET["fDate"];
$iCity = $_GET["iCity"];    
$fCity = $_GET["fCity"];

$query = "SELECT *
          FROM recorridos
          WHERE origen = '$iCity' AND destino = '$fCity' AND fecha = '$iDate'";

$result = mysqli_query($db, $query);

if ($result) 
{
    while($row = mysqli_fetch_object($result))
    {
        echo "<tr> 
              <td> $row->origen </td>
              <td> $row->destino</td>
              <td> $row->fecha</td>
              <td> $row->horario_salida</td>
              </tr>";
    }
}
    
else echo "Query couldn't happen";
?>

